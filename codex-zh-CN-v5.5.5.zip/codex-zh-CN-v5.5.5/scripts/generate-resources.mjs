#!/usr/bin/env node
/**
 * Generate zh-CN resource files from extracted Codex app.asar (dev-time helper).
 * Run after extracting app.asar to .tmp-asar/
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.join(__dirname, "..");
const asarRoot =
  process.env.CODEX_ASAR_ROOT ||
  path.join(root, ".tmp-asar");

function read(file) {
  return fs.readFileSync(path.join(asarRoot, file), "utf8");
}

function getZhVal(zhContent, key) {
  const re = new RegExp(`"${key.replace(/\./g, "\\.")}":\`([^\`]*)\``);
  const m = zhContent.match(re);
  return m ? m[1] : null;
}

const shortcuts = read("webview/assets/electron-menu-shortcuts-DQYPVyfu.js");
const zhBundle = read("webview/assets/zh-CN-wB9Bvfj6.js");
const existingNative = JSON.parse(
  read("native-menu-locales/zh-CN.json")
);

const manualMenuTitle = {
  "codex.commandMenuTitle.copyConversationPath": "复制对话路径",
  "codex.commandMenuTitle.copyDeeplink": "复制深层链接",
  "codex.commandMenuTitle.copySessionId": "复制会话 ID",
  "codex.commandMenuTitle.copyWorkingDirectory": "复制工作目录",
  "codex.commandMenuTitle.closeTabOrWindow": "关闭",
  "codex.commandMenuTitle.reloadBrowserPage": "重新加载浏览器页面",
  "codex.commandMenuTitle.hardReloadBrowserPage": "强制重新加载浏览器页面",
  "codex.commandMenuTitle.newWindow": "新建窗口",
  "codex.commandMenuTitle.openCommandMenu": "打开命令菜单",
  "codex.commandMenuTitle.searchChats": "搜索对话…",
  "codex.commandMenuTitle.searchFiles": "搜索文件…",
  "codex.commandMenuTitle.renameThread": "重命名对话",
  "codex.commandMenuTitle.toggleFileTreePanel": "切换文件树",
  "codex.commandMenuTitle.toggleTraceRecording": "开始跟踪记录",
  "codex.commandMenuTitle.openAvatarOverlay": "唤醒宠物",
};

const menuTitles = [
  ...shortcuts.matchAll(/menuTitle:`([^`]+)`,menuTitleIntlId:`([^`]+)`/g),
];

const nativeMenu = { ...existingNative };
for (const [, title, id] of menuTitles) {
  nativeMenu[id] =
    manualMenuTitle[id] ||
    getZhVal(zhBundle, id) ||
    getZhVal(zhBundle, id.replace("commandMenuTitle", "command")) ||
    title;
}

const hardcoded = [
  ["File", "文件"],
  ["View", "查看"],
  ["Zoom In", "放大"],
  ["Zoom Out", "缩小"],
  ["Actual Size", "实际大小"],
  ["Toggle Full Screen", "切换全屏"],
  ["Codex Documentation", "Codex 文档"],
  ["What's new", "更新日志"],
  ["Automations", "自动化"],
  ["Local Environments", "本地环境"],
  ["Worktrees", "工作树"],
  ["Skills", "技能"],
  ["Model Context Protocol", "模型上下文协议"],
  ["Troubleshooting", "故障排除"],
  ["Send Feedback", "发送反馈"],
  ["Start Performance Trace", "开始性能跟踪"],
  ["Stop Performance Trace", "停止性能跟踪"],
  ["Waiting to Start Trace…", "等待开始跟踪…"],
  ["Saving Trace…", "正在保存跟踪…"],
  ["Waiting for Trace Details…", "等待跟踪详情…"],
  ["Uploading Trace…", "正在上传跟踪…"],
  ["Check for Updates…", "检查更新…"],
  ["Log Out", "退出登录"],
  ["Reload Window", "重新加载窗口"],
  ["Toggle Debug Menu", "切换调试菜单"],
  ["Copy Lin&k", "复制链接"],
  ["Cu&t", "剪切"],
  ["&Copy", "复制"],
  ["&Paste", "粘贴"],
  ["Select &All", "全选"],
  ["Look Up “{selection}”", "查询“{selection}”"],
  ["Save Link As…", "链接另存为…"],
  ["Copy Video Ad&dress", "复制视频地址"],
  ["Save Vide&o", "保存视频"],
  ["Save Video& As…", "视频另存为…"],
  ["C&opy Image Address", "复制图片地址"],
  ["Cop&y Image", "复制图片"],
  ["Sa&ve Image As…", "图片另存为…"],
  ["Save I&mage", "保存图片"],
  ["I&nspect Element", "检查元素"],
];

const resourcesDir = path.join(root, "resources");
fs.mkdirSync(resourcesDir, { recursive: true });
fs.writeFileSync(
  path.join(resourcesDir, "native-menu-zh-CN.json"),
  JSON.stringify(nativeMenu, null, 2),
  "utf8"
);
fs.writeFileSync(
  path.join(resourcesDir, "menu-hardcoded-zh-CN.json"),
  JSON.stringify(hardcoded, null, 2),
  "utf8"
);
fs.writeFileSync(
  path.join(resourcesDir, "release.json"),
  JSON.stringify(
    {
      repo: "YOUR_GITHUB_USER/codex-zh-CN",
      release: "0.1.2",
      supportedCodexVersions: ["26.519.81530"],
    },
    null,
    2
  ),
  "utf8"
);

console.log(`native-menu keys: ${Object.keys(nativeMenu).length}`);
console.log(`hardcoded pairs: ${hardcoded.length}`);
